# PS2 Launcher (NetherSX2)
1. Suba esta pasta num repositório do GitHub -> aba Actions -> "Build APK" -> baixe o artifact PS2Launcher-APK.
2. Ou abra no Android Studio e rode assembleDebug.
3. Instale também o NetherSX2 Classic (3668) — melhor para Mali e 4 GB de RAM. No NetherSX2, aponte a pasta de BIOS para Download/PS2Launcher/BIOS.
