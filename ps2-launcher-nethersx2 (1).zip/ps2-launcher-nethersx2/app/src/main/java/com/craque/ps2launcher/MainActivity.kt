package com.craque.ps2launcher

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val PKGS = listOf("xyz.aethersx2.android", "com.theemulatorapp.nethersx2")
    private val prefs by lazy { getSharedPreferences("ps2", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(16), 0, dp(16)) }
        setContentView(column(
            TextView(this).apply { text = "PS2 Launcher"; textSize = 26f },
            status,
            button("Importar BIOS (.bin)") { pick(1) },
            button("Importar ISO / jogo") { pick(2) },
            button("Configurações do jogo") { startActivity(Intent(this, SettingsActivity::class.java)) },
            button("Jogar no NetherSX2") { play() }
        ))
        refresh()
    }

    private fun pick(code: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, code)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 2) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("iso", uri.toString()).putString("isoName", name(uri)).apply()
        } else if (req == 1) {
            val n = name(uri)
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, n)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/PS2Launcher/BIOS")
            }
            val dst = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            if (dst == null) { toast("Falha ao copiar BIOS"); return }
            contentResolver.openInputStream(uri)!!.use { i -> contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o) } }
            prefs.edit().putString("bios", n).apply()
            toast("BIOS copiada para Download/PS2Launcher/BIOS")
        }
        refresh()
    }

    private fun name(u: Uri) = contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    } ?: "arquivo"

    private fun installed() = PKGS.firstOrNull { p -> try { packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false } }

    private fun refresh() {
        status.text = "NetherSX2: " + (if (installed() != null) "instalado ✔" else "NÃO instalado ✘") +
            "\nBIOS: " + (prefs.getString("bios", null) ?: "não importada") +
            "\nJogo: " + (prefs.getString("isoName", null) ?: "nenhum")
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun play() {
        val pkg = installed() ?: return toast("Instale o NetherSX2 primeiro")
        val iso = prefs.getString("iso", null) ?: return toast("Importe uma ISO primeiro")
        val uri = Uri.parse(iso)
        grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val i = if (pkg == "xyz.aethersx2.android")
            Intent(Intent.ACTION_MAIN).setClassName(pkg, "xyz.aethersx2.android.EmulationActivity")
        else packageManager.getLaunchIntentForPackage(pkg)!!
        i.putExtra("bootPath", iso).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(i) } catch (e: Exception) { toast("Não consegui abrir o NetherSX2: ${e.message}") }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
