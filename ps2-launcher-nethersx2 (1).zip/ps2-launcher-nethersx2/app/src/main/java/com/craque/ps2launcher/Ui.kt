package com.craque.ps2launcher

import android.content.Context
import android.widget.*

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.button(text: String, onClick: () -> Unit) = Button(this).apply {
    this.text = text; setOnClickListener { onClick() }
}

fun Context.column(vararg views: android.view.View): ScrollView {
    val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(32), dp(20), dp(20)) }
    views.forEach { l.addView(it) }
    return ScrollView(this).apply { addView(l) }
}

fun Context.spinner(title: String, options: List<String>, current: Int, onPick: (Int) -> Unit): LinearLayout {
    val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
    row.addView(TextView(this).apply { text = title })
    row.addView(Spinner(this).apply {
        adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, options)
        setSelection(current)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) = onPick(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    })
    return row
}
