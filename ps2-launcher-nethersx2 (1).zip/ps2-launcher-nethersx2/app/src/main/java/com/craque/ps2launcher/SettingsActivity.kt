package com.craque.ps2launcher

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ps2", MODE_PRIVATE) }
    private val renderers = listOf("OpenGL" to 12, "Vulkan" to 14, "Software" to 13)
    private val scales = listOf("1x (nativo)", "2x")
    private val aspects = listOf("4:3", "16:9", "Stretch")
    private val cycles = listOf("Normal (0)", "Rápido (-1)", "Mais rápido (-2)")
    private val cycleVals = intArrayOf(0, -1, -2)
    private val skips = listOf("Desligado", "1", "2")
    private val blends = listOf("Mínimo", "Básico", "Médio")

    // r, s, a, c, m, f, k, b
    private val presetLeve = mapOf("r" to 0, "s" to 0, "a" to 0, "c" to 1, "m" to 0, "f" to 1, "k" to 1, "b" to 0)
    private val presetEquil = mapOf("r" to 0, "s" to 0, "a" to 0, "c" to 0, "m" to 0, "f" to 1, "k" to 0, "b" to 1)

    private fun apply(p: Map<String, Int>) {
        prefs.edit().apply { p.forEach { (k, v) -> putInt(k, v) } }.apply(); recreate()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGb = mi.totalMem / 1024.0 / 1024 / 1024
        fun pick(k: String, d: Int) = prefs.getInt(k, presetLeve[k] ?: d)
        fun put(k: String) = { v: Int -> prefs.edit().putInt(k, v).apply() }
        setContentView(column(
            TextView(this).apply { text = "Configurações do jogo"; textSize = 24f },
            TextView(this).apply { text = "RAM detectada: %.1f GB".format(ramGb); setPadding(0, dp(8), 0, dp(8)) },
            button("Perfil Mali 4 GB — Leve (recomendado)") { apply(presetLeve) },
            button("Perfil Mali — Equilibrado (G76 ou melhor)") { apply(presetEquil) },
            spinner("Renderizador", renderers.map { it.first }, pick("r", 0), put("r")),
            spinner("Resolução interna", scales, pick("s", 0), put("s")),
            spinner("Proporção de tela", aspects, pick("a", 0), put("a")),
            spinner("Ciclos do EE (velocidade)", cycles, pick("c", 0), put("c")),
            spinner("EE cycle skip", skips, pick("k", 0), put("k")),
            spinner("Precisão de blending", blends, pick("b", 0), put("b")),
            spinner("MTVU (multithread VU1)", listOf("Ligado", "Desligado"), pick("m", 0), put("m")),
            spinner("Fast CDVD", listOf("Desligado", "Ligado"), pick("f", 0), put("f")),
            button("Exportar perfil (.ini) de referência") {
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "perfil_ps2.ini")
                }, 3)
            },
            TextView(this).apply {
                text = "\nDicas p/ 4 GB + Mali:\n• Use o NetherSX2 Classic (3668); NÃO use a build Turnip (é só para Adreno).\n" +
                    "• Feche apps em segundo plano e ative o modo desempenho do celular.\n" +
                    "• No NetherSX2: desligue patches de widescreen, cheats e pré-carga de texturas; filtro bilinear; sem anisotrópico/mipmap.\n" +
                    "• Se houver gráficos quebrados no OpenGL, teste Vulkan (e vice-versa).\n\n" +
                    "O Android impede que outro app edite a pasta do NetherSX2: copie os valores do .ini manualmente."
            }
        ))
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        if (req != 3 || res != RESULT_OK) return
        fun g(k: String) = prefs.getInt(k, presetLeve[k] ?: 0)
        val ini = """
[EmuCore/GS]
Renderer = ${renderers[g("r")].second}
upscale_multiplier = ${g("s") + 1}
AspectRatio = ${aspects[g("a")]}
accurate_blending_unit = ${g("b")}
[EmuCore/Speedhacks]
EECycleRate = ${cycleVals[g("c")]}
EECycleSkip = ${g("k")}
vuThread = ${g("m") == 0}
fastCDVD = ${g("f") == 1}
""".trimIndent()
        contentResolver.openOutputStream(uri)!!.use { it.write(ini.toByteArray()) }
        Toast.makeText(this, "Perfil exportado", Toast.LENGTH_SHORT).show()
    }
}
